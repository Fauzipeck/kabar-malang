<?php 
    if($_POST){
        $judul_kuliner=$_POST['judul_kuliner'];
        $tanggal_kuliner=$_POST['tanggal_kuliner'];
        $deskripsi_kuliner=$_POST['deskripsi_kuliner'];
        $deskripsi_kuliner2=$_POST['deskripsi_kuliner2'];
        $foto_kuliner=$_POST['foto_kuliner'];
        $foto_kuliner2=$_POST['foto_kuliner2'];
        if(empty($judul_kuliner)){
            echo "<script>alert('judul kuliner tidak boleh kosong');location.href='tambah_kuliner.php';</script>";  
        } elseif(empty($tanggal_kuliner)){
            echo "<script>alert('tanggal tidak boleh kosong');location.href='tambah_kuliner.php';</script>"; 
        } elseif(empty($deskripsi_kuliner)){
            echo "<script>alert('deskripsi tidak boleh kosong');location.href='tambah_kuliner.php';</script>";
        } elseif(empty($deskripsi_kuliner2)){
                echo "<script>alert('deskripsi tidak boleh kosong');location.href='tambah_kuliner.php';</script>";
        } elseif(empty($foto_kuliner)){
            echo "<script>alert('foto tidak boleh kosong');location.href='tambah_kuliner.php';</script>";
        } elseif(empty($foto_kuliner2)){
            echo "<script>alert('foto tidak boleh kosong');location.href='tambah_kuliner.php';</script>";
        } else {
            include "connection.php";
            $insert=mysqli_query($connection,"insert into kuliner (judul_kuliner, tanggal_kuliner, deskripsi_kuliner, deskripsi_kuliner2, foto_kuliner, foto_kuliner2) value ('".$judul_kuliner."','".$tanggal_kuliner."','".$deskripsi_kuliner."','".$deskripsi_kuliner2."','".$foto_kuliner."','".$foto_kuliner2."')");
            if($insert){
                echo "<script>alert('Sukses menambahkan kuliner');location.href='tambah_kuliner.php';</script>";
            } else {
                echo "<script>alert('Gagal menambahkan kuliner');location.href='tambah_kuliner.php';</script>";
            }
        }
    
    }
?>