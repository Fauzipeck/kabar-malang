<?php 
    if($_POST){
        $judul_kriminal=$_POST['judul_kriminal'];
        $tanggal_kriminal=$_POST['tanggal_kriminal'];
        $deskripsi_kriminal=$_POST['deskripsi_kriminal'];
        $deskripsi_kriminal2=$_POST['deskripsi_kriminal2'];
        $foto_kriminal=$_POST['foto_kriminal'];
        $foto_kriminal2=$_POST['foto_kriminal2'];
        if(empty($judul_kriminal)){
            echo "<script>alert('judul kriminal tidak boleh kosong');location.href='tambah_kriminal.php';</script>";  
        } elseif(empty($tanggal_kriminal)){
            echo "<script>alert('tanggal tidak boleh kosong');location.href='tambah_kriminal.php';</script>"; 
        } elseif(empty($deskripsi_kriminal)){
            echo "<script>alert('deskripsi tidak boleh kosong');location.href='tambah_kriminal.php';</script>";
        } elseif(empty($deskripsi_kriminal2)){
                echo "<script>alert('deskripsi tidak boleh kosong');location.href='tambah_kriminal.php';</script>";
        } elseif(empty($foto_kriminal)){
            echo "<script>alert('foto tidak boleh kosong');location.href='tambah_kriminal.php';</script>";
        } elseif(empty($foto_kriminal2)){
            echo "<script>alert('foto tidak boleh kosong');location.href='tambah_kriminal.php';</script>";
        } else {
            include "connection.php";
            $insert=mysqli_query($connection,"insert into kriminal (judul_kriminal, tanggal_kriminal, deskripsi_kriminal, deskripsi_kriminal2, foto_kriminal, foto_kriminal2) value ('".$judul_kriminal."','".$tanggal_kriminal."','".$deskripsi_kriminal."','".$deskripsi_kriminal2."','".$foto_kriminal."','".$foto_kriminal2."')");
            if($insert){
                echo "<script>alert('Sukses menambahkan kriminal');location.href='tambah_kriminal.php';</script>";
            } else {
                echo "<script>alert('Gagal menambahkan kriminal');location.href='tambah_kriminal.php';</script>";
            }
        }
    
    }
?>