<?php 
    if($_POST){
        $judul_berita=$_POST['judul_berita'];
        $tanggal_berita=$_POST['tanggal_berita'];
        $deskripsi_berita=$_POST['deskripsi_berita'];
        $deskripsi_berita2=$_POST['deskripsi_berita2'];
        $foto_berita=$_POST['foto_berita'];
        $foto_berita2=$_POST['foto_berita2'];
        if(empty($judul_berita)){
            echo "<script>alert('judul berita tidak boleh kosong');location.href='tambah_berita.php';</script>";  
        } elseif(empty($tanggal_berita)){
            echo "<script>alert('tanggal tidak boleh kosong');location.href='tambah_berita.php';</script>"; 
        } elseif(empty($deskripsi_berita)){
            echo "<script>alert('deskripsi tidak boleh kosong');location.href='tambah_berita.php';</script>";
        } elseif(empty($deskripsi_berita2)){
                echo "<script>alert('deskripsi tidak boleh kosong');location.href='tambah_berita.php';</script>";
        } elseif(empty($foto_berita)){
            echo "<script>alert('foto tidak boleh kosong');location.href='tambah_berita.php';</script>";
        } elseif(empty($foto_berita2)){
            echo "<script>alert('foto tidak boleh kosong');location.href='tambah_berita.php';</script>";
        } else {
            include "connection.php";
            $insert=mysqli_query($connection,"insert into berita (judul_berita, tanggal_berita, deskripsi_berita, deskripsi_berita2, foto_berita, foto_berita2) value ('".$judul_berita."','".$tanggal_berita."','".$deskripsi_berita."','".$deskripsi_berita2."','".$foto_berita."','".$foto_berita2."')");
            if($insert){
                echo "<script>alert('Sukses menambahkan berita');location.href='tambah_berita.php';</script>";
            } else {
                echo "<script>alert('Gagal menambahkan berita');location.href='tambah_berita.php';</script>";
            }
        }
    
    }
?>