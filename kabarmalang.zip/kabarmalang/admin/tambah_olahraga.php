<!DOCTYPE html>
<html>
    <head>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
        <title></title>
    </head>
    <body>
    <?php include "homeadmin.php"; ?>
    <h3>Tambah olahraga</h3>
    <form action="proses_tambah_olahraga.php" method="post">
        Judul olahraga :
        <input type="text" name="judul_olahraga" value="" class="form-control">
        Tanggal olahraga :
        <input type="date" name="tanggal_olahraga" value="" class="form-control">
        Deskripsi :
        <input type="text" name="deskripsi_olahraga" value="" class="form-control">
        Deskripsi2 :
        <input type="text" name="deskripsi_olahraga2" value="" class="form-control">
        Foto :
        <input type="text" name="foto_olahraga" value="" class="form-control"> 
        Foto2 :
        <input type="text" name="foto_olahraga2" value="" class="form-control"> 
        <input type="submit" name="simpan" value="Tambah olahraga" class="btn btn-primary">
    </form>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous"></script>
</body>
</html>
