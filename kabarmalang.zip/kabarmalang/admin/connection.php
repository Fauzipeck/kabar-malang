<?php
    $hostname = "localhost";
    $user = "root";
    $pw = "";
    $database = "kabarmalangraya";

    $connection = mysqli_connect ($hostname, $user, $pw, $database);
    if ($connection){
        echo "";
    }
    else{
        die ("Connection failed").mysqli_connect_error();
    }
?>