<?php 
    if($_POST){
        $judul_olahraga=$_POST['judul_olahraga'];
        $tanggal_olahraga=$_POST['tanggal_olahraga'];
        $deskripsi_olahraga=$_POST['deskripsi_olahraga'];
        $deskripsi_olahraga2=$_POST['deskripsi_olahraga2'];
        $foto_olahraga=$_POST['foto_olahraga'];
        $foto_olahraga2=$_POST['foto_olahraga2'];
        if(empty($judul_olahraga)){
            echo "<script>alert('judul olahraga tidak boleh kosong');location.href='tambah_olahraga.php';</script>";  
        } elseif(empty($tanggal_olahraga)){
            echo "<script>alert('tanggal tidak boleh kosong');location.href='tambah_olahraga.php';</script>"; 
        } elseif(empty($deskripsi_olahraga)){
            echo "<script>alert('deskripsi tidak boleh kosong');location.href='tambah_olahraga.php';</script>";
        } elseif(empty($deskripsi_olahraga2)){
                echo "<script>alert('deskripsi tidak boleh kosong');location.href='tambah_olahraga.php';</script>";
        } elseif(empty($foto_olahraga)){
            echo "<script>alert('foto tidak boleh kosong');location.href='tambah_olahraga.php';</script>";
        } elseif(empty($foto_olahraga2)){
            echo "<script>alert('foto tidak boleh kosong');location.href='tambah_olahraga.php';</script>";
        } else {
            include "connection.php";
            $insert=mysqli_query($connection,"insert into olahraga (judul_olahraga, tanggal_olahraga, deskripsi_olahraga, deskripsi_olahraga2, foto_olahraga, foto_olahraga2) value ('".$judul_olahraga."','".$tanggal_olahraga."','".$deskripsi_olahraga."','".$deskripsi_olahraga2."','".$foto_olahraga."','".$foto_olahraga2."')");
            if($insert){
                echo "<script>alert('Sukses menambahkan olahraga');location.href='tambah_olahraga.php';</script>";
            } else {
                echo "<script>alert('Gagal menambahkan olahraga');location.href='tambah_olahraga.php';</script>";
            }
        }
    
    }
?>