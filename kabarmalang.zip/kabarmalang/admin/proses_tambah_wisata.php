<?php 
    if($_POST){
        $judul_wisata=$_POST['judul_wisata'];
        $tanggal_wisata=$_POST['tanggal_wisata'];
        $deskripsi_wisata=$_POST['deskripsi_wisata'];
        $deskripsi_wisata2=$_POST['deskripsi_wisata2'];
        $foto_wisata=$_POST['foto_wisata'];
        $foto_wisata2=$_POST['foto_wisata2'];
        if(empty($judul_wisata)){
            echo "<script>alert('judul wisata tidak boleh kosong');location.href='tambah_wisata.php';</script>";  
        } elseif(empty($tanggal_wisata)){
            echo "<script>alert('tanggal tidak boleh kosong');location.href='tambah_wisata.php';</script>"; 
        } elseif(empty($deskripsi_wisata)){
            echo "<script>alert('deskripsi tidak boleh kosong');location.href='tambah_wisata.php';</script>";
        } elseif(empty($deskripsi_wisata2)){
                echo "<script>alert('deskripsi tidak boleh kosong');location.href='tambah_wisata.php';</script>";
        } elseif(empty($foto_wisata)){
            echo "<script>alert('foto tidak boleh kosong');location.href='tambah_wisata.php';</script>";
        } elseif(empty($foto_wisata2)){
            echo "<script>alert('foto tidak boleh kosong');location.href='tambah_wisata.php';</script>";
        } else {
            include "connection.php";
            $insert=mysqli_query($connection,"insert into wisata (judul_wisata, tanggal_wisata, deskripsi_wisata, deskripsi_wisata2, foto_wisata, foto_wisata2) value ('".$judul_wisata."','".$tanggal_wisata."','".$deskripsi_wisata."','".$deskripsi_wisata2."','".$foto_wisata."','".$foto_wisata2."')");
            if($insert){
                echo "<script>alert('Sukses menambahkan wisata');location.href='tambah_wisata.php';</script>";
            } else {
                echo "<script>alert('Gagal menambahkan wisata');location.href='tambah_wisata.php';</script>";
            }
        }
    
    }
?>