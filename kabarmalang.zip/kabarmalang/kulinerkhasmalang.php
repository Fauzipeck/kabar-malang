<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Profil Kota Malang</title>
  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    .header {
      font-weight: bold;
      color: #6AA6FF;
    }
    .news-box {
      background-color: #e9ecef;
      border-radius: 10px;
      height: 100px;
    }
  </style>
</head>
<body>
    <?php
    include "header.php";
    ?>
  <!-- Content -->
  <div class="container mt-5" style="padding-left: 100px;">
    <h1 class="fw-bold mb-4">Orem-orem Kuliner Khas Kota Malang</h1>
    
    <div class="row">
      <!-- Left Column -->
      <div class="col-lg-8">
        <img src="foto/orem-orem.jpg" style="width: 100%;">
        <br><br>
        <p>kabarmalangraya – Warga Kota Malang pasti tak asing dengan sajian orem-orem. Ya, orem-orem merupakan salah satu makanan khas Kota Malang yang enak disantap baik pagi, siang, bahkan malam.</p>
        <p>Orem-orem merupakan kuliner Jawa dari Kota Malang yang berbahan dasar tempe yang diiris kecil-kecil dan disajikan dengan kuah santan berwarna kuning. Orem-orem biasanya disajikan dengan ketupat atau lontong dan kecambah. Salah satu warung yang menyajikan hidangan ini adalah Warung Orem-Orem H. Abdul Manan. Usaha kuliner ini sudah ada sejak 1967.</p>
        <p>Pemilik Orem-Orem saat membuat orem-orem pesanan pelanggan menceritakan: “Saya generasi kedua, dulu yang mulai bapak saya (H. Abdul Manan). Awalnya keliling dan berpindah-pindah. Tahun 67-an baru pindah ke sini,” ungkap Edy, pemilik warung ini, saat ditemui, Jumat (20/12/2024).</p>
        <br>
        <img src="foto/orem-orem2.jpeg" style="width: 100%;">
        <br><br>
        <p>Orem-orem H. Abdul Manan kuahnya tidak terlalu kental, namun rasanya gurih. Dalam setiap racikan per mangkoknya, Edy menambahkan kecap manis dan taburan bawang goreng. Di warung ini, orem-orem disajikan juga dengan tambahan lauk mendhol atau telur asin. “Tergantung pelanggan mau apa, mau lengkap ya boleh,” celetuk Edy sembari tersenyum.</p>
        <p>Warung ini hanya menyajikan satu menu saja, yakni orem-orem. Walau terlihat sederhana, rupanya rasa orem-orem ini sangat digemari oleh pelanggannya. Bahkan ada pelanggan yang jauh dari luar Kota yang datang. “Saya sudah langganan sejak zaman kuliah dulu, sejak masih keliling dan di pinggir jalan, masih suka makan di sini. Nostalgia,” ujar seorang pelanggan yang datang dari Malang Selatan.</p>
        <p>Seporsi orem-orem biasa dibanderol Rp10.000,00 hingga Rp12.000,00 tergantung dengan tambahan lauk yang dipilih. Warung yang beralamat di Jalan Irian Jaya Nomor 1 ini buka mulai pukul 09.00 – 16.00 WIB dan libur setiap Jumat.</p>
      </div>
      <!-- Right Column -->
      <div class="col-lg-3 bg-light">
        <h4 class="fw-bold">Berita Terkini</h4>
        <?php 
          include "connection.php";
          $qry_berita = mysqli_query($connection, "SELECT * FROM berita");
          while ($dt_berita = mysqli_fetch_array($qry_berita)) {
        ?>
        
        <a href="isiberita.php?id_berita=<?=$dt_berita['id_berita']?>" style="color: black; text-decoration: none;">
          <div class=""><img src="foto/<?= $dt_berita['foto_berita'] ?>" class="news-box mt-3" style="width: 100%;" alt="Foto 1"></div>
          <p class="mt-2 fw-bold"><?= $dt_berita['judul_berita'] ?></p>
        </a>
        <?php } ?>
      </div>
    </div>
  </div>

  <!-- Footer -->
  <?php include "footer.php"; ?>

  <!-- Bootstrap Bundle with Popper -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
