<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible=IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>kuliner</title>
    <link rel="stylesheet" href="kuliner.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <style>
      body {
        display: flex;
        flex-direction: column;
        min-height: 100vh;
        margin: 0;
      }

      .content {
        flex: 1; /* Membuat konten utama fleksibel sehingga footer selalu di bawah */
      }

      .card img {
        width: 100%;
        height: 200px;
        object-fit: cover;
      }

      .card:hover {
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        transform: translateY(-5px);
      }

      .sidebar {
        padding-left: 20px;
      }
    </style>
  </head>
  <body>
    <?php include "header.php"; ?>

    <div class="content">
      <div class="container">
        <div class="row">
          <!-- Konten kuliner -->
          <div class="col-lg-8">
            <div class="row" style="margin-top: 50px;">
              <?php 
                include "connection.php";
                $search_query = isset($_GET['q']) ? $_GET['q'] : '';
                $qry_kuliner = mysqli_query($connection, "SELECT * FROM kuliner WHERE judul_kuliner LIKE '%$search_query%' OR deskripsi_kuliner LIKE '%$search_query%'");
                while ($dt_kuliner = mysqli_fetch_array($qry_kuliner)) {
              ?>
              <div class="col-md-6 mb-4">
                <a href="isikuliner.php?id_kuliner=<?=$dt_kuliner['id_kuliner']?>" style="text-decoration: none;">
                  <div class="card" style="width: 100%;">
                    <img src="foto/<?=$dt_kuliner['foto_kuliner']?>" class="card-img-top" alt="Gambar kuliner">
                    <div class="card-body">
                      <h5 class="card-title"><?=$dt_kuliner['judul_kuliner']?></h5>
                      <p class="card-text"><?=substr($dt_kuliner['deskripsi_kuliner'], 0, 47)?>...</p>
                    </div>
                  </div>
                </a>
              </div>
              <?php } ?>
            </div>
          </div>

          <!-- Sidebar berita terkini -->
          <div class="col-lg-3 bg-light" style="margin-top:50px">
            <h4 class="fw-bold">Berita Terkini</h4>
            <?php 
              include "connection.php";
              $qry_berita = mysqli_query($connection, "SELECT * FROM berita");
              while ($dt_berita = mysqli_fetch_array($qry_berita)) {
            ?>
            
            <a href="isiberita.php?id_berita=<?=$dt_berita['id_berita']?>" style="color: black; text-decoration: none;">
              <div class=""><img src="foto/<?= $dt_berita['foto_berita'] ?>" class="news-box mt-3" style="width: 100%;" alt="Foto 1"></div>
              <p class="mt-2 fw-bold"><?= $dt_berita['judul_berita'] ?></p>
            </a>
            <?php } ?>
          </div>
        </div>
      </div>
    </div>

    <?php include "footer.php"; ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>       
  </body>
</html>
