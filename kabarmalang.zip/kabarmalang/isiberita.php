<?php 
    include "connection.php";
    $qry_detail_berita = mysqli_query($connection, "SELECT * FROM berita WHERE id_berita = '" . $_GET['id_berita'] . "'");
    $dt_berita = mysqli_fetch_array($qry_detail_berita);

    function formatToParagraphs($text) {
        $sentences = preg_split('/(?<=[.?!])\s+/', $text);
        $formattedText = '';
        foreach ($sentences as $sentence) {
            if (trim($sentence) !== '') {
                $formattedText .= '<p class="justify-text">' . trim($sentence) . '</p>';
            }
        }
        return $formattedText;
    }
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Isi berita</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
        <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet"> <!-- Font Awesome -->
        <style>
            .justify-text {
                text-align: justify;
                width: 80%;
            }
            .news-box {
                background-color: #e9ecef;
                border-radius: 10px;
                height: 100px;
            }
        </style>
    </head>
    <body>
        <?php include "header.php"; ?>
        <div class="container mt-5" style="padding-left: 100px;">
            <div class="col-lg-8" style="width: 80%;">
                <h2 class="fw-bold mb-4 text-center text-lg-start"><?= $dt_berita['judul_berita'] ?></h2>
            </div>
            <p>Published by kabarmalangraya <?= $dt_berita['tanggal_berita'] ?></p>

            <div class="row g-0">
                <div class="col-lg-8">
                    <img src="foto/<?= $dt_berita['foto_berita'] ?>" class="img-fluid mb-4" style="width: 80%;" alt="Foto 1">
                    <?= formatToParagraphs($dt_berita['deskripsi_berita']) ?>
                    <img src="foto/<?= $dt_berita['foto_berita2'] ?>" class="img-fluid mb-4" style="width: 80%;" alt="Foto 2">
                    <?= formatToParagraphs($dt_berita['deskripsi_berita2']) ?>
                </div>

                <div class="col-lg-3 bg-light">
                    <h4 class="fw-bold">Berita Terkini</h4>
                    <?php 
                    include "connection.php";
                    $qry_berita = mysqli_query($connection, "SELECT * FROM berita");
                    while ($dt_berita = mysqli_fetch_array($qry_berita)) {
                    ?>
                    
                    <a href="isiberita.php?id_berita=<?=$dt_berita['id_berita']?>" style="color: black; text-decoration: none;">
                    <div class=""><img src="foto/<?= $dt_berita['foto_berita'] ?>" class="news-box mt-3" style="width: 100%;" alt="Foto 1"></div>
                    <p class="mt-2 fw-bold"><?= $dt_berita['judul_berita'] ?></p>
                    </a>
                    <?php } ?>
                </div>
            </div>
        </div>

        <?php include "footer.php"; ?>

        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    </body>
</html>
