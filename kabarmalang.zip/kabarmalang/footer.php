<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Footer Update</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
        <!-- Font Awesome -->
        <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
        <style>
            footer {
                background-color: black;
                color: white;
                padding: 20px;
                margin-top: 20px;
                position: relative;
                text-align: center;
                display: flex;
                justify-content: space-between; /* Untuk posisi ikon dan teks */
                align-items: center;
            }

            footer p {
                margin: 0;
                flex-grow: 1; /* Membuat teks copyright tetap di tengah */
                text-align: center;
            }

            footer .social-icons {
                display: flex;
                gap: 15px; /* Jarak antar ikon */
            }

            footer .social-icons a {
                color: white;
                font-size: 1.5em;
                transition: color 0.3s ease;
            }

            footer .social-icons a:hover {
                color: #f39c12;
            }
        </style>
    </head>
    <body>
        <!-- Footer -->
        <footer>
            <p class="mb-0">Copyright 2024 kabarmalangraya</p>
            <div class="social-icons">
                <a href="https://www.instagram.com" target="_blank"><i class="fab fa-instagram"></i></a>
                <a href="https://www.facebook.com" target="_blank"><i class="fab fa-facebook"></i></a>
                <a href="mailto:info@kabarmalangraya.com"><i class="fas fa-envelope"></i></a>
            </div>
        </footer>

        <!-- Bootstrap JS dan Font Awesome JS -->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-pd6ntxFx+YNNSsTc6DdcpXHO07S2gPjRJ4XVRVuiT5dxCUjRSI2kwKweG5nkkmy9" crossorigin="anonymous"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/js/all.min.js"></script>
    </body>
</html>
