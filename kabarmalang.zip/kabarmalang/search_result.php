<?php
// Ambil kata kunci dari parameter GET
$keyword = isset($_GET['q']) ? htmlspecialchars($_GET['q']) : '';

if ($keyword) {
    echo "<h1>Hasil Pencarian untuk: $keyword</h1>";

    // Simulasi data hasil pencarian
    $dummyData = [
        "Berita Malang Terbaru",
        "Kuliner Khas Malang yang Wajib Dicoba",
        "Wisata Hits di Malang Raya",
        "Olahraga Lokal yang Sedang Trending",
    ];

    $results = array_filter($dummyData, function($item) use ($keyword) {
        return stripos($item, $keyword) !== false;
    });

    if ($results) {
        echo "<ul>";
        foreach ($results as $result) {
            echo "<li>$result</li>";
        }
        echo "</ul>";
    } else {
        echo "<p>Tidak ada hasil ditemukan untuk kata kunci \"$keyword\".</p>";
    }
} else {
    echo "<p>Masukkan kata kunci untuk mencari.</p>";
}
?>
