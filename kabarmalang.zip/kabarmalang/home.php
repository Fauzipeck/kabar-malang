<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Profil Kota Malang</title>
  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    .header {
      font-weight: bold;
      color: #6AA6FF;
    }
    .news-box {
      background-color: #e9ecef;
      border-radius: 10px;
      height: 100px;
    }
  </style>
</head>
<body>
    <?php
    include "header.php";
    ?>
  <!-- Content -->
  <div class="container mt-5" style="padding-left: 100px;">
    <h1 class="fw-bold mb-4">Profil Kota Malang</h1>
    
    <div class="row">
      <!-- Left Column -->
      <div class="col-lg-8">
        <img src="foto/malang.png" style="width: 100%;">
        <br><br>
        <p>Kota Malang adalah sebuah kota yang terletak di provinsi Jawa Timur, Indonesia. Kota ini memiliki sejarah yang kaya, keindahan alam yang menakjubkan, serta berbagai destinasi wisata yang menarik. Malang terletak di bagian tengah Jawa Timur dan dikelilingi oleh pegunungan serta dataran rendah.</p>
        <p>Kota ini memiliki iklim tropis dengan suhu yang sejuk di dataran tinggi dan sedikit lebih hangat di dataran rendah. Kota ini didirikan pada masa Pemerintahan Belanda pada 1 April 1914 dengan E.K Broeveldt sebagai wali kota pertama. Kota ini terletak di dataran tinggi seluas 145,28 km² yang merupakan enklave Kabupaten Malang. Bersama dengan Kota Batu dan Kabupaten Malang, Kota Malang merupakan bagian dari kesatuan wilayah yang dikenal dengan Malang Raya.</p>
        <h3 class="mt-4">Sejarah Kota Malang</h3>
        <br>
        <img src="foto/malang2.jpg" style="width: 100%;">
        <br><br>
        <p>Kota Malang, yang terletak di Jawa Timur, memiliki sejarah panjang yang kaya. Pada abad ke-8, wilayah ini merupakan pusat Kerajaan Kanjuruhan, salah satu kerajaan Hindu tertua di Nusantara. Prasasti Dinoyo (760 M) mencatat kejayaan Kerajaan Kanjuruhan di bawah Raja Gajayana, yang terkenal dengan kepeduliannya terhadap rakyat dan pengembangan kebudayaan Hindu. Bukti peninggalan zaman ini meliputi artefak arkeologi yang menunjukkan peradaban maju.</p>
        <p>Pada abad ke-13, Malang menjadi bagian dari Kerajaan Singhasari, yang didirikan oleh Ken Arok. Di bawah Raja Kertanegara, Singhasari mencapai puncak kejayaannya dan melakukan ekspedisi besar seperti Ekspedisi Pamalayu. Peninggalan sejarah dari era ini, seperti Candi Singosari dan arca-arca kuno, menjadi saksi penting akan masa kejayaan Malang dalam sejarah kerajaan Nusantara. Setelah Singhasari runtuh, wilayah ini menjadi bagian dari Kerajaan Majapahit hingga abad ke-16.</p>
        <p>Pada masa kolonial Belanda, Kota Malang berkembang menjadi pusat perdagangan dan pemukiman penting karena lokasinya yang strategis dan iklimnya yang sejuk. Pemerintah kolonial membangun infrastruktur modern, seperti jalan raya, perumahan bergaya Eropa, dan fasilitas umum, yang masih dapat dilihat hingga kini. Setelah Indonesia merdeka, Malang terus berkembang menjadi salah satu kota besar dengan ciri khasnya sebagai pusat pendidikan, budaya, dan pariwisata.</p>
        <h3 class="mt-4">Malang Kota Pendidikan</h3>
        <br>
        <img src="foto/brawijaya.png" style="width: 100%;">
        <br><br>
        <p>Kota Malang dikenal sebagai salah satu kota pendidikan terkemuka di Indonesia, dengan julukan "Kota Pendidikan." Kota ini menjadi pusat belajar bagi siswa dan mahasiswa dari berbagai daerah, berkat keberadaan institusi pendidikan berkualitas. Mulai dari sekolah dasar hingga perguruan tinggi, Malang menawarkan berbagai pilihan lembaga pendidikan dengan fasilitas modern. Universitas ternama seperti Universitas Brawijaya (UB), Universitas Negeri Malang (UM), dan Politeknik Negeri Malang (Polinema) telah melahirkan banyak lulusan yang berkontribusi besar dalam berbagai bidang.</p>
        <p>Faktor pendukung utama status Malang sebagai kota pendidikan adalah lingkungan yang kondusif untuk belajar. Iklim yang sejuk, suasana kota yang nyaman, serta biaya hidup yang relatif terjangkau menjadikan Malang pilihan ideal bagi pelajar dan mahasiswa. Selain itu, berbagai program pengembangan pendidikan dari pemerintah setempat terus dilakukan, seperti beasiswa untuk siswa berprestasi dan pembangunan infrastruktur pendidikan yang semakin baik.</p>
        <p>Keberadaan Malang sebagai kota pendidikan juga membawa dampak positif bagi perekonomian lokal. Banyaknya pelajar yang datang ke Malang menciptakan peluang usaha di bidang properti, makanan, dan kebutuhan sehari-hari. Selain itu, berbagai komunitas belajar, seminar, dan event pendidikan rutin diselenggarakan, menjadikan Malang pusat inovasi dan diskusi ilmiah. Dengan segala keunggulannya, Malang terus memperkuat posisinya sebagai kota pendidikan yang tidak hanya berfokus pada akademik, tetapi juga pembentukan karakter generasi muda.</p>
        <h3 class="mt-4">Ekonomi dan Pariwisata</h3>
        <br>
        <img src="foto/alunalun.jpg" style="width: 100%;">
        <br><br>
        <p>Ekonomi Kota Malang tumbuh dari berbagai sektor utama, seperti pertanian, industri, perdagangan, dan pariwisata. Sektor pertanian menyumbang peran penting dengan hasil utama berupa apel Malang, sayuran, dan bunga. Industri di Malang juga berkembang pesat, khususnya industri makanan, minuman, dan kerajinan lokal yang banyak dipasarkan hingga ke luar daerah. Perdagangan di kota ini didukung oleh keberadaan pasar tradisional, pusat perbelanjaan modern, serta industri kreatif yang terus bertumbuh, menjadikan Malang pusat ekonomi regional yang dinamis.</p>
        <p>Pariwisata menjadi salah satu pilar utama ekonomi Malang, menawarkan beragam destinasi yang menarik wisatawan lokal maupun internasional. Tempat-tempat seperti Alun-Alun Kota Malang, Kampung Warna-Warni Jodipan, dan Taman Wisata Wendit menjadi daya tarik khas yang memadukan keindahan alam, seni, dan budaya. Selain itu, kota ini juga memiliki berbagai kafe, restoran, dan hotel yang mendukung sektor pariwisata. Keberagaman destinasi dan kemudahan akses transportasi menjadikan pariwisata sebagai sektor strategis yang terus mendorong pertumbuhan ekonomi Kota Malang.</p>
        <h3 class="mt-4">Budaya dan Kuliner</h3>
        <br>
        <img src="foto/budaya.jpg" style="width: 100%;">
        <br><br>
        <p>Kota Malang memiliki budaya yang kaya dan beragam, dipengaruhi oleh sejarah panjangnya sebagai bagian dari berbagai kerajaan dan penjajahan. Budaya lokal tercermin dalam tradisi seni seperti tari topeng Malangan, yang mengisahkan legenda dan cerita rakyat dengan gerakan khas dan kostum yang indah. Selain itu, Malang memiliki tradisi unik dalam perayaan seperti Grebeg Tirto Aji di kawasan sumber mata air, yang melambangkan penghormatan terhadap alam.</p>
        <p>Kuliner Malang sangat terkenal dan menjadi daya tarik wisata. Berbagai makanan khas seperti bakso Malang, dengan isian lengkap berupa bakso, tahu, dan pangsit, menjadi ikon kuliner yang mendunia. Selain itu, rawon, pecel, dan nasi jagung juga menjadi favorit lokal yang mencerminkan keanekaragaman rasa. Malang juga dikenal dengan jajanan tradisional seperti kue putu, cenil, dan klepon, serta hasil pertanian khas seperti apel Malang yang segar dan berkualitas tinggi. Kuliner Malang menggambarkan harmoni antara tradisi dan kreativitas yang terus berkembang.</p>
      </div>
      <!-- Right Column -->
      <div class="col-lg-3 bg-light">
        <h4 class="fw-bold">Berita Terkini</h4>
        <?php 
          include "connection.php";
          $qry_berita = mysqli_query($connection, "SELECT * FROM berita");
          while ($dt_berita = mysqli_fetch_array($qry_berita)) {
        ?>
        
        <a href="isiberita.php?id_berita=<?=$dt_berita['id_berita']?>" style="color: black; text-decoration: none;">
          <div class=""><img src="foto/<?= $dt_berita['foto_berita'] ?>" class="news-box mt-3" style="width: 100%;" alt="Foto 1"></div>
          <p class="mt-2 fw-bold"><?= $dt_berita['judul_berita'] ?></p>
        </a>
        <?php } ?>
      </div>
    </div>
  </div>

  <!-- Footer -->
  <?php include "footer.php"; ?>

  <!-- Bootstrap Bundle with Popper -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
