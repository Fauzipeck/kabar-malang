<?php 
session_start();
include 'connection.php';

$username=$_POST['username'];
$password=$_POST['password'];

$login=mysqli_query($connection,"select * from admin where username='$username' and password='$password'");
$cek=mysqli_num_rows($login);
if($cek > 0){
    $data=mysqli_fetch_assoc($login);
        $_SESSION['username']=$username;
        
        //masuk ke folder admin
        header("location:admin/homeadmin.php");
}else{

    header("location:index.php?pesan=gagal");

}

?>