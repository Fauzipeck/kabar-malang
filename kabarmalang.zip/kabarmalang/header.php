<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Document</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
        <style>
            .navbar-nav .nav-link:hover,
            .navbar-nav .nav-link:focus,
            .navbar-nav .nav-link.active {
                color:rgb(231, 207, 48) !important;
            }
            .header {
                font-weight: bold;
                color: #6AA6FF;
            }
            .news-box {
                background-color: #e9ecef;
                border-radius: 10px;
                height: 100px;
            }
            footer {
                background-color: black;
                color: white;
                text-align: center;
                margin-top: 20px;
                padding: 10px;
                border-radius: 0 0 10px 10px;
            }
            .navbar-brand {
                font-family: Braah One;
                font-size: 50px; /* Ukuran font logo */
                color: #6AA6FF; /* Warna biru */
                font-weight: bold; /* Font bold */
            }

            .navbar-toggler-icon {
                color: white;
            }
            .navbar-nav .nav-link {
                font-size: 1.2rem;
                color: white; /* Warna tulisan navbar menjadi putih */
            }
            .navbar-nav {
                margin-left: 0; /* Menggeser menu navbar ke kiri */
            }

            /* Responsif input search */
            .input-group {
                width: 100%; /* Menggunakan 100% lebar container */
                max-width: 500px; /* Batas lebar maksimum */
            }

            .form-control {
                font-size: 1rem;
                padding: 10px; /* Menambah padding agar lebih lebar */
            }

            .search-button {
                width: 50px;
                height: 50px;
                background-color: #6AA6FF;
                border: none;
                border-radius: 50%;
            }

            .search-button img {
                width: 25px;
                height: 25px;
            }

            /* Menyesuaikan dengan ukuran layar kecil */
            @media (max-width: 768px) {
                .navbar-brand {
                    font-size: 35px; /* Mengurangi ukuran font logo di layar kecil */
                }
                .input-group {
                    width: 80%; /* Mengurangi lebar input pada layar kecil */
                }
            }
        </style>
    </head>
    <body>
        <!-- Navbar -->
        <nav class="navbar navbar-expand-lg bg-body-tertiary">
            <div class="container-fluid">
                <a class="navbar-brand ms-4 fs-1" href="home.php" style="">kabarmalangraya</a>
                <form class="d-flex ms-auto" role="search"  method="GET" style="padding-right: 100px;">
                    <div class="input-group">
                        <input class="form-control rounded-5" type="search" name="q" placeholder="Search" aria-label="Search">
                    </div>
                </form>
            </div>
        </nav>

        <nav class="navbar navbar-expand-lg navbar-dark" style="background-color: black;">
            <div class="container">
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav ms-0"> <!-- Menggeser menu ke kiri -->
                        <li class="nav-item">
                            <a class="nav-link" href="home.php">Profil</a>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="kulinerDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                Berita
                            </a>
                            <ul class="dropdown-menu" aria-labelledby="kulinerDropdown">
                                <li><a class="dropdown-item" href="berita.php">Berita Nasional</a></li>
                                <li><a class="dropdown-item" href="kriminal.php">Berita Kriminal</a></li>
                            </ul>
                        </li>        
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="kulinerDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                Kuliner
                            </a>
                            <ul class="dropdown-menu" aria-labelledby="kulinerDropdown">
                                <li><a class="dropdown-item" href="kulinerkhasmalang.php">Kuliner Khas Malang</a></li>
                                <li><a class="dropdown-item" href="kulinerviral.php">Kuliner Viral Malang</a></li>
                            </ul>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="wisata.php">Wisata</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="olahraga.php">Olahraga</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="login.php">Login</a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>

        <!-- Tambahkan Bootstrap JS dengan CDN -->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-pd6ntxFx+YNNSsTc6DdcpXHO07S2gPjRJ4XVRVuiT5dxCUjRSI2kwKweG5nkkmy9" crossorigin="anonymous"></script>
    </body>
</html>
